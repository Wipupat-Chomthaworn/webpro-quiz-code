# WEEK06-VUE-2 Part 1

แบบฝึกหัดสัปดาห์ที่ 6 Vue JS (2) - Part 1


## วิธีการทำแบบฝึกหัด
1. ดาวโหลดน์ Zip หรือ Clone โฟลเดอร์นี้ลงในคอมพิวเตอร์ของตัวเอง
```
git clone https://github.com/it-web-pro/WEEK06-VUE-2.git
```
2. เปิดโฟลเดอร์ที่ดาวน์โหลดมาด้วย VSCode
3. เปิด Live Server และไปที่ http://localhost:5500

สามารถแก้ไข code vue ใน tag script ในไฟล์ .html ได้เลย
