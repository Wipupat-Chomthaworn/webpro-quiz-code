const province = JSON.parse(`[
  {
    "id": 1,
    "name_th": "กรุงเทพมหานคร",
    "name_en": "Bangkok"
  },
  {
    "id": 2,
    "name_th": "สมุทรปราการ",
    "name_en": "Samut Prakan"
  }
]`);
