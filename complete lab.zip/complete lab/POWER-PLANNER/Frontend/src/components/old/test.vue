<template>
    <div>{{ message }}</div>
</template>
<script>
export default {
    name:"test",
    data(){
        return {
        message:"HI"
        }
    }
    }
</script>
<style></style>