# WEEK03-EXERCISE

แบบฝึกหัดสัปดาห์ที่ 3


## วิธีการทำแบบฝึกหัด
1. ดาวโหลดน์ Zip หรือ Clone โฟลเดอร์นี้ลงในคอมพิวเตอร์ของตัวเอง
```
git clone https://github.com/it-web-pro/WEEK03-EXERCISE.git
```
2. เปิดโฟลเดอร์ที่ดาวน์โหลดมาด้วย VSCode
3. เปิด Live Server และไปที่ http://localhost:5500
