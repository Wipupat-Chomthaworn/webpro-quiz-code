# WEEK05-EXERCISE

แบบฝึกหัดสัปดาห์ที่ 5 Vue JS - Part 1


## วิธีการทำแบบฝึกหัด
1. ดาวโหลดน์ Zip หรือ Clone โฟลเดอร์นี้ลงในคอมพิวเตอร์ของตัวเอง
```
git clone https://github.com/it-web-pro/WEEK05-VUE-1.git
```
2. เปิดโฟลเดอร์ที่ดาวน์โหลดมาด้วย VSCode
3. เปิด Live Server และไปที่ http://localhost:5500
