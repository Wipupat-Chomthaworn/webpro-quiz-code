var app = new Vue({
    el: '#ex1',
    data: {
        student_id: '64070125',
        student_fname: 'Kampanat',
        student_lname: 'Konklong'
    },


})
